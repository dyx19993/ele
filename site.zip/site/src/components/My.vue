<template>
    <div>
        <slot name="one" :age="age" userName="daiyuanxi"></slot>
    </div>
</template>

<script>
    export default {
        name: "My",
        data(){
            return {
                age:12
            }
        }
    }
</script>

<style scoped>

</style>