export default {
    EleHeader:()=>import("@/components/common/Eleheader")
}