import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
    {
        // 有地址导航的，都作为该路由的子路由
        name: "index",
        path: "/",
        component: () => import("@/views/Index"),
        children: [
            {
                path: "/",
                name: "home",
                component: () => import("@/views/Home")
            }, {
                path:"/order",
                name:"order",
                meta:{
                    // 当该值为true时，验证你是否登陆。
                    isAuthorization:true
                },
                component:()=>import("@/views/Order")
            }, {
                path:"/my",
                name:"my",
                meta:{
                    // 当该值为true时，验证你是否登陆。
                    isAuthorization:true
                },
                component:()=>import("@/views/My")
            }
        ]
    },{
        path:"/login",
        name:"login",
        component:()=>import("@/views/Login")
    },{
        path:"/address",
        name:"address",
        component:()=>import("@/views/Address")
    },{
        path:"/search",
        name:"search",
        component:()=>import("@/views/search")
    },{
        path:"/shopDetail/:shopId.html",
        name:"shopDetail",
        component:()=>import("@/views/ShopDetail")
    },{
        path:"/shopList/:shopTypeId.html",
        name:"shopList",
        component:()=>import("@/views/shopList")
    },{
        path:"/mySlot",
        name:"mySlot",
        component:()=>import("@/views/MySlot")
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes,
    linkActiveClass:"is-selected"//选中样式
})

router.beforeEach((to,from,next)=>{
    if(to.meta.isAuthorization){
       if(localStorage.token){
        next();
       }else{
        next("/login")
       }
    }else{
        next()
    }
    // console.log(11111111,to.meta.isAuthorization);
    next()
})
export default router
