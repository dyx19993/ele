const state = {
    tips:[],
    formattedAddress:localStorage.formattedAddress || "",
}
const mutations = {
    CHANGE_TIPS(state,tips){
        state.tips=tips
    },
    CHANGE_ADDRESS(state,formattedAddress){
        state.formattedAddress=formattedAddress
    }
}
const actions = {
    // 获得定位
    getFormattedAddress({commit}){
        if(!localStorage.formattedAddress){
            commit("CHANGE_ADDRESS","定位中……");
            
            AMap.plugin('AMap.Geolocation', function() {
                console.log(111)
                var geolocation = new AMap.Geolocation({
                    // 是否使用高精度定位，默认：true
                    enableHighAccuracy: true,
                    // 设置定位超时时间，默认：无穷大
                    timeout: 100
                })

                geolocation.getCurrentPosition();
                AMap.event.addListener(geolocation, 'complete', onComplete)
                AMap.event.addListener(geolocation, 'error', onError)

                function onComplete (data) {
                    // data是具体的定位信息
                    commit("CHANGE_ADDRESS",data);
                }
                function onError (data) {
                    // 定位出错
                    AMap.plugin('AMap.CitySearch', function () {
                        var citySearch = new AMap.CitySearch()
                        citySearch.getLocalCity(function (status, result) {
                          if (status === 'complete' && result.info === 'OK') {
                            // 查询成功，result即为当前所在城市信息
                            console.log(result)
                            commit("CHANGE_ADDRESS",result.province+result.city);
                          }
                        })
                      })
                }
            })
        }
    },
    autocomplete({commit},keyword){
        AMap.plugin('AMap.Autocomplete', function() {
            var  autoOptions={
                city:'全国'
            }
            var autoComplete= new AMap.Autocomplete(autoOptions);
            autoComplete.search(keyword,function(status,result){
                console.log(result.tips);
                commit("CHANGE_TIPS",result.tips)
            })
            })
    }
}



export default {
    state,
    mutations,
    actions
}