import axios  from 'axios'
const state = {
    token:localStorage.token ||null,
    phoneCode:localStorage.phoneCode || null
}
const mutations = {
    CHANGE_TOKEN(state,{token,phoneCode}){
        state.token = localStorage.token = token;
        state.phoneCode = localStorage.phoneCode = phoneCode;
    },
    // 退出登陆
    OUT_LOGIN(state){
        localStorage.clear();
        state.token = state.phoneCode = null;
    }
}
const actions = {
    async login({commit},{phoneCode,code}){
        const {data} = await axios.post("/ele/login",{
            phoneCode,
            code
        })
        console.log(data)
        if(data.ok===1){
            commit("CHANGE_TOKEN",{token:data.token,phoneCode})
            $router.push(-1)
        }else{
            alert(data.msg);
        }
    }
}


export default {
    state,
    mutations,
    actions
}