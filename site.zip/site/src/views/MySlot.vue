<template>
    <My>
        <template v-slot:one="data">
            v-slot{{data.userName}} |{{data.age}}
        </template>
    </My>
</template>
<script>
    export default {
        name: "MySlot",
        components:{
            My:()=>import("@/components/My")
        }
    }
</script>

<style scoped>

</style>