<template>
       <div class="index">
                <router-view></router-view>

          <!--头部 豆腐块-->
           <TabBar></TabBar>
        </div>
</template>

<script>
    export default {
        name: "Index",
        components: {
          TabBar:()=>import("../components/TabBar")
        }
    }
</script>

<style scoped>
.index {
    width: 100%;
    height: calc(100% - 45px);
  }
</style>