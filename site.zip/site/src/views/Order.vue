<template>
    <div>订单</div>
</template>

<script>
    export default {
        name: "Order"
    }
</script>

<style scoped>

</style>