<template>
  <div class="goods">
    <div/>
    <div class="goods">
      <EleHeader>
      <h1 class="header-title">{{shopInfo.shopName}}</h1>
    </EleHeader>
    <div class="header" style="background:#fff"><img v-if="shopInfo.shopPic" :src="'/ele/'+shopInfo.shopPic" alt=""></div>
        <div>
            <div class="left">
              <section v-for="item in goodsTypeInfo"  :key="item._id" class="index-container">
                <div class="type" @click="tab(item.goodsTypeName)">
                  <p style="font-size:18px">{{item.goodsTypeName}}</p>
                </div>
              </section>
            </div>
            <div class="right">
              <section  v-for="item in goodsInfo"    :key="item._id" class="index-container">
            <div class="index-shopInfo" v-show="item.goodsTypeName == goodsType" >
                <!-- 左侧图片 -->
                <div class="logo_container">
                    <img :src="'/ele/'+item.goodsPic">
                </div>
                <!-- 右侧内容 -->
                <div class="index_main" >
                    <!-- 第一行 品牌 -->
                    <div class="index_shopname">
                        <i>商品</i>
                        <span>{{item.goodsName}}</span>
                    </div>

                    <!-- 第二行 星级 -->
                    <div class="index-rateWrap">
                        <div>
                            <span>月售12份</span>
                        </div>
                    </div>

                    <!-- 第三行 配送 -->
                    <div class="index-moneylimit">
                        <div>
                            <span style="color:red;font-size:20px">¥20</span>
                        </div>
                    </div>
                </div>
            </div>
          </section>
            </div>
        </div>
      </div>
    </div>
</template>
<script>
export default {
  name: "ShopDetail",
  data() {
    return {
      goodsType:"",
      shopInfo: {},
      goodsTypeInfo:{},
      goodsInfo:{}
    };
  },
  methods: {
      tab(goodsType){
        this.goodsType = goodsType
      }
  },
  async mounted() {
    // console.log(this.$route.params.shopId);
    const { data } = await this.$axios.get(
      "/ele/shopInfo/" + this.$route.params.shopId
    );
    this.shopInfo = data.shopInfo;
    const goodsTypeRes = await this.$axios.get(
      "/ele/goodsTypeList/" + this.$route.params.shopId
    );
    this.goodsTypeInfo = goodsTypeRes.data.goodsTypeList;
    // console.log(goodsTypeRes.data.goodsTypeList);
    const goodsRes = await this.$axios.get(
      "/ele/goodsList/" + this.$route.params.shopId
    );
    this.goodsInfo = goodsRes.data.goodsList;
    // console.log(goodsRes.data.goodsList);
  }
};

</script>
<style scoped>
*{
  margin: 0;
  padding: 0;
}
  .header img{
    width: 100%;
    height: 20vm;
  }
  .left{
    width:30%;
    float: left;
    padding: 20px 0 20px 0;
  }
  .type{
    padding: 15px 5px 20px 10px;
  }
  .right{
    width: 70%;
    float: right;

  }
  .goods{
    background: #fff;
    height: 100%;
  }
</style>